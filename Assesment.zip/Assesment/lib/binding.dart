import 'package:get/get.dart';
import 'auth_controller.dart';
import 'task_controller.dart';

class InitialBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut(() => AuthController());
    Get.lazyPut(() => TaskController());
  }
}
