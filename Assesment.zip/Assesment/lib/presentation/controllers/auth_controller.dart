import 'dart:ui';

import 'package:get/get.dart';
import 'package:firebase_auth/firebase_auth.dart';

class AuthController extends GetxController {
  final FirebaseAuth _auth = FirebaseAuth.instance;

  User? get user => _auth.currentUser;

  Future<bool> login(String email, String password) async {
    try {
      await _auth.signInWithEmailAndPassword(email: email, password: password);
      Get.offAllNamed('/tasks');
      return true;
    } catch (e) {
      print("Login error: $e");
      Get.snackbar(
        'Login Failed',
        e.toString(),
        snackPosition: SnackPosition.BOTTOM,
        backgroundColor: const Color(0xFFFFCDD2),
        colorText: const Color(0xFFB71C1C),
        duration: const Duration(seconds: 3),
      );
      return false;
    }
  }

  Future<bool> signup(String email, String password) async {
    try {
      await _auth.createUserWithEmailAndPassword(
        email: email,
        password: password,
      );
      Get.offAllNamed('/tasks');
      return true;
    } catch (e) {
      print("Signup error: $e");
      Get.snackbar(
        'Signup Failed',
        e.toString(),
        snackPosition: SnackPosition.BOTTOM,
        backgroundColor: const Color(0xFFFFF9C4),
        colorText: const Color(0xFFF57F17),
        duration: const Duration(seconds: 3),
      );
      return false;
    }
  }

  void logout() async {
    await _auth.signOut();
    Get.offAllNamed('/login');
  }
}
