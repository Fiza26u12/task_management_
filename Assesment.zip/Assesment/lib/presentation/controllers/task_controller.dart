import 'package:get/get.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class TaskController extends GetxController {
  final RxList<DocumentSnapshot> tasks = <DocumentSnapshot>[].obs;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final FirebaseAuth _auth = FirebaseAuth.instance;

  Stream<User?> get authStateChanges => _auth.authStateChanges();

  @override
  void onInit() {
    super.onInit();

    authStateChanges.listen((user) {
      if (user != null) {
        _listenToTasks(user.uid);
      }
    });
  }

  void _listenToTasks(String uid) {
    _firestore
        .collection('users')
        .doc(uid)
        .collection('tasks')
        .snapshots()
        .listen((snapshot) {
          tasks.value = snapshot.docs;
        });
  }

  Future<void> addTask(String title, String description, String status) async {
    try {
      final uid = _auth.currentUser?.uid;
      if (uid == null) {
        return;
      }

      await _firestore.collection('users').doc(uid).collection('tasks').add({
        'title': title,
        'description': description,
        'status': status,
      });
    } catch (e) {
      print(e);
    }
  }

  Future<void> updateTask(String taskId, Map<String, dynamic> data) async {
    final uid = _auth.currentUser?.uid;
    if (uid == null) {
      return;
    }

    await _firestore
        .collection('users')
        .doc(uid)
        .collection('tasks')
        .doc(taskId)
        .update(data);
  }

  Future<void> deleteTask(String taskId) async {
    final uid = _auth.currentUser?.uid;
    if (uid == null) {
      return;
    }

    await _firestore
        .collection('users')
        .doc(uid)
        .collection('tasks')
        .doc(taskId)
        .delete();
  }
}
