import 'package:assessment/middilewares.dart';
import 'package:assessment/presentation/screens/signup_screen.dart';
import 'package:get/get.dart';
import 'presentation/screens/login_screen.dart';
import 'presentation/screens/task_list_screen.dart';
import 'presentation/screens/add_task_screen.dart';
import 'presentation/screens/edit_task_screen.dart';

class AppRoutes {
  static final routes = [
    GetPage(name: '/login', page: () => LoginScreen()),
    GetPage(
      name: '/tasks',
      page: () => TaskListScreen(),
      middlewares: [AuthMiddleware()],
    ),
    GetPage(name: '/signup', page: () => SignupScreen()),
    GetPage(name: '/add-task', page: () => AddTaskScreen()),
    GetPage(name: '/edit-task', page: () => EditTaskScreen()),
  ];
}
